var floodedVally = extend(SectorPreset, "fuck", Planets.serpulo, 174, {
    localizedName: "Forgotten Caldera",
    description: "A forgotten research center, abandoned when the Crux invaded. Recover the technology before the Crux can. Gain the upper hand."
    details: "Reports indicate experimental units still patrol this facility. They will be like nothing you have ever faced before. Be prepared."
    difficulty: 10,
    alwaysUnlocked: true
});